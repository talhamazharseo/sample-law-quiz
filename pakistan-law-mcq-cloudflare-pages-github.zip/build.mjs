import { access, cp, mkdir, rm } from "node:fs/promises";
import { constants } from "node:fs";
import { resolve } from "node:path";

const sourceDirectory = resolve("public");
const outputDirectory = resolve("dist");
const requiredFiles = ["index.html", "style.css", "script.js"];

async function verifySourceFiles() {
  for (const file of requiredFiles) {
    const path = resolve(sourceDirectory, file);

    try {
      await access(path, constants.R_OK);
    } catch {
      throw new Error(`Missing required source file: public/${file}`);
    }
  }
}

async function build() {
  await verifySourceFiles();
  await rm(outputDirectory, { recursive: true, force: true });
  await mkdir(outputDirectory, { recursive: true });
  await cp(sourceDirectory, outputDirectory, { recursive: true });

  console.log("Cloudflare Pages build completed.");
  console.log(`Output directory: ${outputDirectory}`);
}

build().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
