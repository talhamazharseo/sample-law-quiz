# Pakistan Law MCQ Quiz — Cloudflare Pages

A static bilingual English and Urdu quiz with 20 easy Pakistan criminal and civil law MCQs.

## Cloudflare Pages Build Settings

Use these exact settings when importing the GitHub repository:

| Setting | Value |
|---|---|
| Framework preset | None |
| Production branch | `main` |
| Root directory | `/` |
| Build command | `npm run build` |
| Build output directory | `dist` |
| Deploy command | Leave blank for normal Pages Git integration |
| Node.js version | 22 |

Do not use `npx wrangler deploy` as the deploy command for a normal Cloudflare Pages Git-connected project. Cloudflare Pages deploys the generated `dist` directory automatically after the build succeeds.

## Repository Structure

```text
.
├── public/
│   ├── index.html
│   ├── style.css
│   ├── script.js
│   ├── favicon.svg
│   ├── robots.txt
│   ├── 404.html
│   └── _headers
├── build.mjs
├── package.json
├── wrangler.jsonc
├── .gitignore
└── README.md
```

## Local Build Test

```bash
npm run build
```

The deployable website will be generated in:

```text
dist/
```

## Optional Manual Deployment

After authenticating Wrangler, you may deploy manually with:

```bash
npm run deploy
```

Wrangler may ask you to choose or create a Cloudflare Pages project.

## Fixing “Failed While Fetching Repository”

This error happens before Cloudflare reads or builds the website files. It normally indicates a GitHub connection or repository-permission problem.

1. Confirm that the repository still exists and the production branch is `main`.
2. In GitHub, open **Settings → Applications → Installed GitHub Apps**.
3. Open the Cloudflare installation and confirm that it can access this repository.
4. If access looks correct but the error continues, uninstall the Cloudflare GitHub app and reconnect the repository from Cloudflare.
5. Return to the Cloudflare project and retry the deployment.

## Quiz Behavior

- One answer may be selected for each question.
- The answer locks immediately.
- The selected answer cannot be changed.
- Correct or incorrect feedback is hidden during the quiz.
- The score and complete answer review appear only after all 20 questions.
- English and Urdu are shown together.

## Disclaimer

This website is for educational purposes only and is not legal advice.
